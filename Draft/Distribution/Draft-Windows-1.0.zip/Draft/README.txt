Draft Application for Windows

==========================

Requirements:

- Java 20 or later must be installed

Installation:

1. Extract all files to any location on your computer

2. Double-click "Launch-Draft.bat" to run the application


Troubleshooting:

- If the application does not start, ensure Java is installed and in your PATH

- To check your Java version, open Command Prompt and type: java -version
