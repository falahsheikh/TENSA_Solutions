#!/bin/bash

echo "Starting Draft Application..."

java -jar Draft.jar
